/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad6_1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Ebert
 */
public class Actividad6_1 {

    public static void main(String[] args) {
        String user, nomArchivo, lineasArchivo;
        Pattern pat = null;
        Matcher mat = null;
        int estado = 0;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Logger logger = Logger.getLogger("MyLog");

        try {
            FileHandler fh = new FileHandler("registro.log", true);
            // Creamos el manejador de archivo para el registro
            logger.addHandler(fh);
            // Asociamos el manejador al logger
            logger.setUseParentHandlers(false);
            // Deshabilitamos los manejadores padres para evitar la salida a consola
            logger.setLevel(Level.ALL);
            // Establecemos el nivel de registro para registrar todos los eventos
            SimpleFormatter formatter = new SimpleFormatter();
            // Creamos un formateador simple para el registro
            fh.setFormatter(formatter);
            // Establecemos el formateador para el manejador de archivo

            do {
                System.out.println("Introducir nombre de usuario, debe ser de 8 caracteres en minúscula.");
                user = reader.readLine();
                logger.log(Level.INFO, "Usuario introducido: " + user);

                pat = Pattern.compile("^[a-z]{8}$");
                // Patrón para verificar que el nombre de usuario tenga 8 caracteres en minúscula
                mat = pat.matcher(user);

                if (mat.matches()) {
                    estado = 1;
                    System.out.println("Usuario aceptado");
                    do {
                        System.out.println("Ingresa el nombre del archivo del que quieres ver su contenido, "
                                + "el nombre de archivo debe ser de 8 caracteres y tener una extensión "
                                + "de 3 caracteres (Puedes probar con prueba01.txt y prueba02.txt):");
                        nomArchivo = reader.readLine();

                        logger.log(Level.INFO, "Nombre de archivo introducido: " + nomArchivo);
                        // Registramos el nombre de archivo introducido

                        pat = Pattern.compile("^[a-zA-Z0-9]{8}\\.[a-z]{3}$");
                        // Patrón para verificar el formato del nombre de archivo
                        mat = pat.matcher(nomArchivo);

                        if (mat.matches()) {
                            estado = 2;
                            try {
                                FileReader f = new FileReader(nomArchivo);
                                BufferedReader b = new BufferedReader(f);
                                logger.log(Level.INFO, "Se muestra el archivo: " + nomArchivo);

                                System.out.println("\nContenido:");

                                while ((lineasArchivo = b.readLine()) != null) {

                                    System.out.println(lineasArchivo);
                                }
                                b.close();

                                do {
                                    System.out.println("\n¿Quiere ver algún otro archivo? (s|n)");
                                    String eleccion = reader.readLine();
                                    if (eleccion.equalsIgnoreCase("s")) {
                                        logger.log(Level.INFO, "Se visualiza otro archivo");
                                        estado = 1;
                                    } else if (eleccion.equalsIgnoreCase("n")) {
                                        logger.log(Level.INFO, "Sesión cerrada");
                                        estado = 2;
                                    } else {
                                        logger.log(Level.WARNING, "Opción no reconocida");
                                        System.err.println("Opción no reconocida");
                                        estado = 3;
                                    }
                                } while (estado == 3);

                            } catch (FileNotFoundException e) {
                                System.err.println("Archivo solicitado no existe");
                                logger.log(Level.WARNING, "Archivo solicitado no existe");
                                estado = 1;
                            }
                        } else {
                            logger.log(Level.WARNING, "Formato de archivo incorrecto: " + nomArchivo);
                            System.err.println("Formato de archivo no permitido");
                        }
                    } while (estado == 1);
                } else {
                    logger.log(Level.WARNING, "Formato de nombre incorrecto: " + user);
                    System.err.println("Formato de nombre incorrecto");

                }
            } while (estado == 0);
        } catch (IOException e) {
            System.err.println(e.toString());
        }
    }

}
